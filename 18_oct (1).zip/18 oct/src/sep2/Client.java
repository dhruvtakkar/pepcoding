package sep2;

public class Client {

	public static void main(String[] args) {
//		int[] arr;
//		
//		arr = new int[3];
//		System.out.println(arr.length);
//		arr[0] = 100;
//		arr[1] = 59;
//		arr[2] = 82;
//		
//		for(int i = 0; i < arr.length; i++){
//			System.out.println(arr[i]);
//		}
		
//		int[] arr = {55, 92, 110, 73, 62};
//		for(int val: arr){
//			System.out.print(val + " ");
//		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
