package sep1;

public class Arrays {

	public static void main(String[] args) {

	}

}
